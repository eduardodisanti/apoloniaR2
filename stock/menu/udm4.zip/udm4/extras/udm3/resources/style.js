//UDMv3.8.6

//**line-height switch ****************************************
var lineHeightSwitch=false;
//**DO NOT EDIT THIS ******************************************
if(!exclude){var d=document;var mrSize,srSize;if(typeof fSIZE=="number"){mrSize=fSIZE+"px";}else {if(fSIZE=="x-small"){mrSize="xx-small";if(com){mrSize="x-small";}fSIZE=10;}else if(fSIZE=="small") {mrSize="x-small";if(com){mrSize="small";}fSIZE=13;}else if(fSIZE=="medium"){mrSize="small";if(com){mrSize="medium";}fSIZE=16;}else if(fSIZE=="large"){mrSize="medium";if(com){mrSize="large";}fSIZE=19;}else if(fSIZE=="x-large"){mrSize="large";if(com){mrSize="x-large";}fSIZE=24;}else {mrSize="x-small";if(com){mrSize="small";}fSIZE=13;}}if(menuALIGN=="free"){mrSize=fSIZE+"px";}if(typeof sfSIZE=="number"){srSize=sfSIZE+"px";}else {if(sfSIZE=="x-small"){srSize="xx-small";if(com){srSize="x-small";}sfSIZE=10;}else if(sfSIZE=="small") {srSize="x-small";if(com){srSize="small";}sfSIZE=13;}else if(sfSIZE=="medium"){srSize="small";if(com){srSize="medium";}sfSIZE=16;}else if(sfSIZE=="large"){srSize="medium";if(com){srSize="large";}sfSIZE=19;}else if(sfSIZE=="x-large"){srSize="large";if(com){srSize="x-large";}sfSIZE=24;}else{srSize="x-small";if(com){srSize="small";}sfSIZE=13;}}if(menuALIGN=="free"){srSize=sfSIZE+"px";}if((!mac&&ns4)||(mac&&op5)){fSIZE+=1;sfSIZE+=1;}if(lin&&op7){fSIZE-=2;sfSIZE-=2;}if(bSIZE<0)bSIZE=0;if(fSIZE<5)fSIZE=5;if(tINDENT<0)tINDENT=0;if(vPADDING<1)vPADDING=1;if(sbSIZE<0)sbSIZE=0;if(sfSIZE<5) sfSIZE=5;if(stINDENT<0)stINDENT=0;if(svPADDING<0)svPADDING=0;if(fWEIGHT=="")fWEIGHT="normal";if(sfWEIGHT=="")sfWEIGHT="normal";if(shSIZE<0){shSIZE=0;}if(menuALIGN=="virtual"){remoteTRIGGERING=1;menuALIGN="left";if(ns4||op5||op6||(mac&&ie5)){if(allowRESIZE==mu){allowRESIZE=true;}}else {if(allowRESIZE==mu){allowRESIZE=false;}}staticMENU=0;}if(ns4&&shCOLOR==""){shCOLOR="#cccccc";shSIZE=0;}var sty='';sty+='<style type="text/css"><!--';sty+='.mTD,.mTD A:Link,.mTD A:Visited \{color:'+aLINK+'\}';sty+='.mTD,.mTD A \{';if(!ns4){sty+='white-space:nowrap\;';}sty+='color:'+aLINK+'\;font-weight:'+fWEIGHT+'\;\}';sty+='.mTD,.mTD A:Active,.mTD A:Link,.mTD A:Visited,.mTD A:Hover\{font-weight:'+fWEIGHT+'\;font-size:'+fSIZE+'px\;font-family:'+fFONT+'\;text-decoration:'+aDEC+'\;';if(!ns4){sty+='position:relative\;';}sty+='\}';sty+='.SUBmTD,.SUBmTD A \{';if(!ns4){sty+='white-space:nowrap\;';}sty+='color:'+saLINK+'\;font-weight:'+sfWEIGHT+'\;\}';sty+='.SUBmTD,.SUBmTD A:Link,.SUBmTD A:Visited \{color:'+saLINK+'\}';sty+='.SUBmTD,.SUBmTD A:Active,.SUBmTD A:Link,.SUBmTD A:Visited,.SUBmTD A:Hover\{font-weight:'+sfWEIGHT+'\;font-size:'+sfSIZE+'px\;font-family:'+sfFONT+'\;text-decoration:'+saDEC+'\;\}';if(lineHeightSwitch){if(ie){sty+='#udm-n,#udm-navbar,.restore,.printhide,.linkspan,#underb td,#mas span{line-height:100%\;\}';}if(ns4){sty+='.restore span,.restore div,.restore td{line-height:100%\;\}';}if(ns6||mz7||op7){sty+='.printhide div,.mTD span,.SUBmTD span{line-height:100%\;\}';}if(op6){sty+='.printhide td{line-height:100%\;\}';}if(op5){sty+='.printhide td,.printhide span{line-height:100%\;\}';}}if(win&&ie5){sty+='.u\{text-decoration:underline\;\}';}
//*************************************************************
//****##### USE THIS SPACE FOR NEW STYLE DEFINITIONS #####*****




//** DO NOT EDIT THIS ****************************************
sty+='//--></style>';if(!allowPRINTING&&!ns4&&!(mac&&ie4)&&!kde&&!ice&&!saf){sty+='<style type="text/css" media="print">';sty+='.printhide \{display:none\;\}';sty+='</style>';}d.write(sty);};function genericOnloadFunction(){menuReadyState=1;
//*************************************************************
//****##### USE THIS SPACE TO DEFINE ONLOAD FUNCTIONS #####****




//** DO NOT EDIT THIS *****************************************
if(ns4){nsinit();}}
//*************************************************************