// UK lang variables

tinyMCE.addToLang('',{
insert_image_alt2 : 'Titel plaatje',
insert_image_onmousemove : 'Alternatief plaatje',
insert_image_mouseover : 'voor muis over',
insert_image_mouseout : 'voor muis out'
});
