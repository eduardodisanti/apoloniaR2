// UK lang variables

tinyMCE.addToLang('',{
insert_image_alt2 : 'N�zev obr�zku',
insert_image_onmousemove : 'Alternativn� obr�zek',
insert_image_mouseover : 'p�i najet� my�i',
insert_image_mouseout : 'p�i odjet� my�i'
});
