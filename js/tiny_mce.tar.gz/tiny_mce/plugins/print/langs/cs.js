/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id$ 
 */  

tinyMCE.addToLang('',{
print_desc : 'Tisk'
});

