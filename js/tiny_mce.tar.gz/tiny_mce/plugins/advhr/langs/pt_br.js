// pt_BR lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Inserir / editar Linha Horizontal',
insert_advhr_width : 'Largura',
insert_advhr_size : 'Altura',
insert_advhr_noshade : 'Sem Sombra'
});
