// DE lang variables 

tinyMCE.addToLang('',{
insertdate_def_fmt : '%Y-%m-%d',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Datum einf&uuml;gen',
inserttime_desc : 'Zeit einf&uuml;gen',
inserttime_months_long : new Array("Januar", "Februar", "M&auml;rz", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"),
inserttime_months_short : new Array("Jan", "Feb", "M&auml;r", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"),
inserttime_day_long : new Array("Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"),
inserttime_day_short : new Array("So", "Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")
});
