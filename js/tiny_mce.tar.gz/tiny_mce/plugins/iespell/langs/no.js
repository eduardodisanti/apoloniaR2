// NO lang variables by Knut B. Jacobsen

tinyMCE.addToLang('',{
iespell_desc : 'Kj&oslash;r rettstavingskontroll',
iespell_download : "ieSpell virker ikke &aring; v&aelig;re installert. Klikk OK for &aring; laste hjem."
});
