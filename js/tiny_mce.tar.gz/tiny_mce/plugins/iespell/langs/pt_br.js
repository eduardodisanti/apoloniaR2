// pt_BR lang variables

tinyMCE.addToLang('',{
iespell_desc : 'Executar verifica��o ortogr�fica',
iespell_download : "Verificador ieSpell n�o detectado. Click OK para ir � p�gina de download."
});
