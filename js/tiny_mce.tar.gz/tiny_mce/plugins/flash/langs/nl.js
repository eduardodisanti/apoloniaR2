// NL lang variables

tinyMCE.addToLang('',{
insert_flash : 'Invoegen / wijzigen Flash Movie',
insert_flash_file : 'Flash-Bestand (.swf)',
insert_flash_size : 'Grootte'
});
