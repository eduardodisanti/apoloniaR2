// PL lang variables

tinyMCE.addToLang('',{
preview_desc : 'Podglad'
});
