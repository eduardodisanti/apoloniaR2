// DE lang variables

tinyMCE.addToLang('',{
preview_desc : 'Vorschau'
});
