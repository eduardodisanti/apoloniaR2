// IR lang variables
// Persian (Farsi) language pack (for IRAN)
// By: Morteza Zafari
// Lost@LostLord.com
// http://www.LostLord.com

tinyMCE.addToLang('',{
dir : 'rtl',
preview_desc : '??? ?????'
});
