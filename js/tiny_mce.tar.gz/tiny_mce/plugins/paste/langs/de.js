// DE lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Als unformatierten Text einf&uuml;gen',
paste_text_title : 'Benutzen Sie Strg+V/Apfel-V auf Ihrer Tastatur, um Text in das Fenster einzuf&uuml;gen.',
paste_text_linebreaks : 'Zeilenumbr&uuml;che beibehalten',
paste_word_desc : 'Microsoft Word-Text einf&uuml;gen',
paste_word_title : 'Benutzen Sie Strg+V/Apfel-V auf Ihrer Tastatur, um Text in das Fenster einzuf&uuml;gen.',
selectall_desc : 'Alles ausw&auml;hlen'
});
