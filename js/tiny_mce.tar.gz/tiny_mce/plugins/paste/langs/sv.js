// SV lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Klistra in som vanlig text',
paste_text_title : 'Anv&auml;nd CTRL+V p&aring; ditt tangentbord f&ouml;r att klistra in i detta f&ouml;nster.',
paste_text_linebreaks : 'Spara radbrytningar',
paste_word_desc : 'Klistra in fr&aring;n Word',
paste_word_title : 'Anv&auml;nd CTRL+V p&aring; ditt tangentbord f&ouml;r att klistra in i detta f&ouml;nster.',
selectall_desc : 'Select All'
});
