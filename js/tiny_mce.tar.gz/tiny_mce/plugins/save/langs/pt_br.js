// pt_BR lang variables

tinyMCE.addToLang('',{
save_desc : 'Salvar'
});
