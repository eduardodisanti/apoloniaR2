// pt_BR lang variables

tinyMCE.addToLang('',{
insert_link_target_same : 'Abrir nesta mesma janela / frame',
insert_link_target_parent : 'Abrir na janela / frame pr�via',
insert_link_target_top : 'Abrir no frame superior (substitui todos os frames)',
insert_link_target_blank : 'Abrir em nova janela',
insert_link_target_named : 'Abrir na janela',
insert_link_popup : 'JS-Popup',
insert_link_popup_url : 'Popup URL endere�o',
insert_link_popup_name : 'Nome da janela',
insert_link_popup_return : 'inserir \'retorna falso\'',
insert_link_popup_scrollbars : 'Mostra barras de rolagem',
insert_link_popup_statusbar : 'Mostra barra de status',
insert_link_popup_toolbar : 'Mostra barras de ferramentas',
insert_link_popup_menubar : 'Mostra barra de menu',
insert_link_popup_location : 'Mostra barra de endere�o',
insert_link_popup_resizable : 'Permite redimensionamento da janela',
insert_link_popup_size : 'Tamanho',
insert_link_popup_position : 'Posi��o (X/Y)',
insert_link_popup_missingtarget : 'Por Favor insira um nome para o alvo ou escolha outra op��o.'
});
