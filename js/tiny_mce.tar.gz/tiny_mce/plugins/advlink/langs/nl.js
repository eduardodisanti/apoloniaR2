// NL lang variables

tinyMCE.addToLang('',{
insert_link_target_same : 'Open in dit window / frame',
insert_link_target_parent : 'Open in parent window / frame',
insert_link_target_top : 'Open in top frame (vervangt alle frames)',
insert_link_target_blank : 'Open in nieuw window',
insert_link_target_named : 'Open in het window',
insert_link_popup : 'JS-Popup',
insert_link_popup_url : 'Popup URL',
insert_link_popup_name : 'Window naam',
insert_link_popup_return : 'invoegen \'return false\'',
insert_link_popup_scrollbars : 'Laat scrollbars zien',
insert_link_popup_statusbar : 'Laat statusbar zien',
insert_link_popup_toolbar : 'Laat toolbars zien',
insert_link_popup_menubar : 'Laat menubar zien',
insert_link_popup_location : 'Laat locatiebar zien',
insert_link_popup_resizable : 'Maak window resizable',
insert_link_popup_size : 'Grootte',
insert_link_popup_position : 'Positie (X/Y)',
insert_link_popup_missingtarget : 'Geef de naam van het target window of kies een andere optie.'
});
